# TSM-TV untuk Android dan Android TV

Cara mendapatkan APK tanpa memasang apa pun di komputer:

1. Buat akun di github.com (gratis), lalu buat repositori baru, misalnya `tsm-tv`.
2. Unggah seluruh isi folder ini ke repositori itu (tombol "Add file" > "Upload files"). Pastikan folder `.github` ikut terunggah.
3. Buka tab **Actions**. Build berjalan otomatis dan selesai dalam 3 sampai 6 menit. Bila tidak berjalan, pilih "Build APK" lalu "Run workflow".
4. Buka build yang sudah hijau, lalu unduh **TSM-TV-apk** di bagian Artifacts. Ekstrak ZIP-nya, di dalamnya ada `app-debug.apk`.
5. Pasang `app-debug.apk` di HP atau TV (izinkan "Install dari sumber tidak dikenal").

Alternatif: buka folder ini di Android Studio, lalu pilih Build > Build APK(s).

Catatan: APK ini ditandatangani dengan kunci debug, cukup untuk pemakaian pribadi di perangkatmu sendiri.
