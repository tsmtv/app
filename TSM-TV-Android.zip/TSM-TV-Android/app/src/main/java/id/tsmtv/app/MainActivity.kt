package id.tsmtv.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var lastBack = 0L

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data))
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            keepScreenOn = true
            isFocusable = true
            isFocusableInTouchMode = true
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = true
                // Halaman dimuat dari file lokal aplikasi. Dua opsi ini membuat playlist dan EPG
                // dari URL bisa diambil tanpa terhalang aturan CORS.
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                userAgentString = userAgentString + " TSMTV-Android"
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean =
                    request.url.scheme != "file"
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView,
                    callback: ValueCallback<Array<Uri>>,
                    params: FileChooserParams
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    return try {
                        chooser.launch(params.createIntent())
                        true
                    } catch (e: Exception) {
                        fileCallback = null
                        callback.onReceiveValue(null)
                        Toast.makeText(this@MainActivity, "Perangkat ini tidak punya pemilih file. Gunakan opsi tempel teks.", Toast.LENGTH_LONG).show()
                        false
                    }
                }
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        web.requestFocus()

        // Tombol Kembali: diteruskan ke aplikasi web (tutup dialog, keluar layar penuh).
        // Tekan dua kali dalam 2 detik untuk keluar.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val now = System.currentTimeMillis()
                if (now - lastBack < 2000) {
                    finish()
                    return
                }
                lastBack = now
                web.evaluateJavascript(
                    "document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}))", null
                )
                Toast.makeText(this@MainActivity, "Tekan Kembali sekali lagi untuk keluar", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // Tombol channel di remote diteruskan sebagai PageUp/PageDown.
        val mapped = when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP -> "PageUp"
            KeyEvent.KEYCODE_CHANNEL_DOWN -> "PageDown"
            else -> null
        }
        if (mapped != null) {
            web.evaluateJavascript(
                "document.dispatchEvent(new KeyboardEvent('keydown',{key:'$mapped',bubbles:true}))", null
            )
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
